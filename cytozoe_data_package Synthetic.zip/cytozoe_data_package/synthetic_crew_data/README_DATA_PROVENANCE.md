# CytoZoe – Synthetic Crew Data (DATA PROVENANCE)

**All data in this folder is SYNTHETIC. It is not real astronaut data.**
Every file carries a `data_origin = SYNTHETIC` column.

## Why synthetic
Real in-flight astronaut vitals (continuous HR/HRV/BP/SpO2/ECG) are not publicly downloadable.
They are held under NASA/ESA/JAXA privacy and informed-consent rules and require a formal data
request (e.g. NASA Life Sciences Portal, ESA HREDA). CytoZoe was built on a synthetic dataset so the
full pipeline could be developed and demonstrated; the loader is designed so real data can be swapped in.

## What it is based on (qualitative, not copied)
- Published ISS/Shuttle cardiovascular literature: in-flight HR roughly flat to modestly changed
  with large individual variation, slightly lower BP in flight, HRV changes, and an elevated HR with
  lower BP/HRV in the hours-days after landing.
- Trends digitized by eye from ESA HREDA "Cardiovascular Data" (STS-51-G, DOI 10.57780/esa-gvmt8d5),
  used only to shape relative changes (percent from baseline), not absolute values.
- Parameters are illustrative. They are NOT validated against any real astronaut dataset.

## Files
| File | Content |
|---|---|
| `crew_vitals_1min.csv` | 4 fictional crew, 14 days (2 pre-flight, 10 in-flight, 2 post-flight), 1-min resolution: HR, RMSSD, SDNN (5-min surrogate), SBP/DBP (cuff every 15 min, else blank), SpO2, activity, labelled events, signal-quality flag |
| `crew_metadata.csv` | Fictional baselines per crew member |
| `ecg_250hz.csv` | 30-s ECG at 250 Hz per crew for 3 conditions: rest, exercise, tachycardia + PVCs |
| `ecg_rpeaks.csv` | Ground-truth R-peak times and beat type (N normal, V ventricular) |
| `generate_synthetic_crew_data.py` | Reproducible generator (`python generate_synthetic_crew_data.py <seed>`) |

## Labelled events (for alert testing)
`tachycardia`, `hypoxemia`, `hypotension`, `hypertension` (in-flight, 6 per crew member).
Dropouts appear as `signal_quality = dropout` with blank HR/HRV/SpO2.

## Known limitations
- Simplified physiology: circadian, sleep, exercise, flight adaptation and post-landing decay only.
- ECG is a template-based simulation, not a physiological model; PVC segments inflate RMSSD.
- Not suitable for clinical validation or for drawing scientific conclusions about astronauts.
