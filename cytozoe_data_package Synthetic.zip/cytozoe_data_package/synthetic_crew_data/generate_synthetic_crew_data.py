"""
CytoZoe - SYNTHETIC crew vital-sign generator.
ALL OUTPUT IS SYNTHETIC. It is NOT real astronaut data.
Parameters are loosely informed by published spaceflight cardiovascular literature
(in-flight HR/BP/HRV trends, post-landing HR rise, STS-51-G digitized trends) - see README.
Usage: python generate_synthetic_crew_data.py [seed]
"""
import sys, numpy as np, pandas as pd
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 42
rng = np.random.default_rng(SEED)

START = pd.Timestamp("2026-01-01 00:00:00", tz="UTC")
PRE_DAYS, FLIGHT_DAYS, POST_DAYS = 2, 10, 2
N_DAYS = PRE_DAYS + FLIGHT_DAYS + POST_DAYS
N = N_DAYS * 1440
LAUNCH_MIN = PRE_DAYS * 1440
LAND_MIN = (PRE_DAYS + FLIGHT_DAYS) * 1440

# Fictional crew: baselines (resting, pre-flight) and individual response to microgravity
CREW = [
    dict(crew_id="CREW-A", age=45, sex="M", hr0=62, sbp0=118, dbp0=74, spo2_0=98.0, rmssd0=42, flight_hr_pct=0.06),
    dict(crew_id="CREW-B", age=39, sex="F", hr0=66, sbp0=108, dbp0=68, spo2_0=98.3, rmssd0=50, flight_hr_pct=0.02),
    dict(crew_id="CREW-C", age=51, sex="M", hr0=57, sbp0=124, dbp0=79, spo2_0=97.6, rmssd0=34, flight_hr_pct=0.10),
    dict(crew_id="CREW-D", age=42, sex="M", hr0=70, sbp0=121, dbp0=77, spo2_0=97.9, rmssd0=38, flight_hr_pct=-0.02),
]

def ar1(n, phi, sd):
    e = rng.normal(0, sd * np.sqrt(1 - phi**2), n)
    x = np.zeros(n)
    for i in range(1, n):
        x[i] = phi * x[i-1] + e[i]
    return x

def smooth(x, w):
    k = np.ones(w) / w
    return np.convolve(x, k, mode="same")

t = np.arange(N)
hour = (t / 60.0) % 24
day = t // 1440
phase = np.where(t < LAUNCH_MIN, "preflight", np.where(t < LAND_MIN, "in-flight", "postflight"))
sleep = (hour >= 22) | (hour < 6)
exercise = (hour >= 12) & (hour < 13.5) & (t < LAND_MIN - 0) & ~((day >= N_DAYS - POST_DAYS))
activity = np.where(sleep, "sleep", np.where(exercise, "exercise", "work"))
# ramp into flight adaptation over ~2 days, and post-landing decay
f = np.clip((t - LAUNCH_MIN) / (2 * 1440), 0, 1) * (t < LAND_MIN)
dt_h = np.where(t >= LAND_MIN, (t - LAND_MIN) / 60.0, np.inf)
post = np.where(np.isfinite(dt_h), np.exp(-dt_h / 40.0), 0.0)

rows, meta = [], []
for c in CREW:
    circ = 5.0 * np.sin(2 * np.pi * (hour - 10) / 24)   # lowest ~04:00, highest ~16:00
    ex_ramp = smooth(exercise.astype(float), 15)
    hr_t = (c["hr0"] * (1 + c["flight_hr_pct"] * f + 0.22 * post)
            + circ + np.where(sleep, -9, 4) + 55 * ex_ramp)
    hr = hr_t + ar1(N, 0.95, 2.2)

    # HRV: falls with HR, higher in sleep, slight in-flight rise, post-landing dip
    rmssd = (c["rmssd0"] * np.exp(-0.03 * (hr - c["hr0"])) * np.where(sleep, 1.35, 1.0)
             * (1 + 0.06 * f) * (1 - 0.25 * post) * np.exp(ar1(N, 0.9, 0.12)))
    sdnn = rmssd * 1.5 * np.exp(ar1(N, 0.9, 0.06))   # 5-min-window surrogate

    sbp = (c["sbp0"] + 4 * np.sin(2 * np.pi * (hour - 10) / 24) + np.where(sleep, -9, 2)
           + 35 * ex_ramp - 5 * f - 7 * post + ar1(N, 0.9, 3.0))
    dbp = c["dbp0"] + 0.45 * (sbp - c["sbp0"]) + ar1(N, 0.9, 2.0)

    spo2 = (c["spo2_0"] + np.where(sleep, -0.4, 0) - 0.8 * ex_ramp + ar1(N, 0.8, 0.35))

    event = np.array(["none"] * N, dtype=object)
    quality = np.array(["ok"] * N, dtype=object)
    # inject labelled events in-flight, off-exercise, aligned to 15-min grid
    kinds = ["tachycardia", "hypoxemia", "hypotension", "hypertension", "tachycardia", "hypoxemia"]
    for k in kinds:
        while True:
            s = int(rng.integers(LAUNCH_MIN + 1440, LAND_MIN - 120) // 15 * 15)
            dur = {"tachycardia": 15, "hypoxemia": 10, "hypotension": 30, "hypertension": 30}[k]
            if not exercise[s:s+dur].any() and (event[s:s+dur] == "none").all():
                break
        sl = slice(s, s + dur)
        if k == "tachycardia": hr[sl] += 45 * np.hanning(dur) + 10
        if k == "hypoxemia":   spo2[sl] -= rng.uniform(6, 9) * np.hanning(dur) + 1
        if k == "hypotension": sbp[sl] -= 30; dbp[sl] -= 18
        if k == "hypertension": sbp[sl] += 38; dbp[sl] += 20
        event[sl] = k
    # sensor dropouts
    for _ in range(3):
        s = int(rng.integers(0, N - 30)); d = int(rng.integers(5, 21))
        quality[s:s+d] = "dropout"

    df = pd.DataFrame(dict(
        timestamp_utc=(START + pd.to_timedelta(t, unit="m")).strftime("%Y-%m-%dT%H:%M:%SZ"),
        crew_id=c["crew_id"], phase=phase,
        mission_day=np.where(t < LAUNCH_MIN, day - PRE_DAYS, np.where(t < LAND_MIN, day - PRE_DAYS + 1, day - PRE_DAYS - FLIGHT_DAYS)),
        activity=activity,
        hr_bpm=np.clip(hr, 35, 200).round(1),
        rmssd_ms=np.clip(rmssd, 3, 150).round(1),
        sdnn_ms=np.clip(sdnn, 5, 200).round(1),
        sbp_mmhg=sbp.round(0), dbp_mmhg=dbp.round(0),
        spo2_pct=np.clip(np.round(spo2), 70, 100),
        event_label=event, signal_quality=quality))
    # BP is an intermittent cuff reading every 15 min, like real monitors
    cuff = (t % 15 != 0)
    df.loc[cuff, ["sbp_mmhg", "dbp_mmhg"]] = np.nan
    df.loc[df.signal_quality == "dropout", ["hr_bpm", "rmssd_ms", "sdnn_ms", "spo2_pct"]] = np.nan
    rows.append(df)
    meta.append({k: c[k] for k in ["crew_id", "age", "sex", "hr0", "sbp0", "dbp0", "spo2_0", "rmssd0", "flight_hr_pct"]})

vitals = pd.concat(rows, ignore_index=True)
vitals.insert(0, "data_origin", "SYNTHETIC")
vitals.to_csv("crew_vitals_1min.csv", index=False)
pd.DataFrame(meta).assign(data_origin="SYNTHETIC").to_csv("crew_metadata.csv", index=False)

# ---------------- ECG (250 Hz) ----------------
FS = 250
def beat(tt, rr, ventricular=False):
    if ventricular:
        comps = [(1.35, 0.0, 0.032), (-0.45, 0.22, 0.07)]
    else:
        sc = np.sqrt(rr / 0.8)
        comps = [(0.12, -0.20 * sc, 0.025), (-0.10, -0.03, 0.010), (1.0, 0.0, 0.012),
                 (-0.22, 0.03, 0.010), (0.30, 0.25 * sc, 0.045)]
    return sum(a * np.exp(-0.5 * ((tt - m) / w) ** 2) for a, m, w in comps)

def synth_ecg(hr, rmssd_ms, dur=30, pvc_prob=0.0):
    mean_rr = 60.0 / hr
    s = rmssd_ms / 1000 / np.sqrt(2)
    rr, tcur, times, types = [], 0.3, [], []
    pause = False
    while tcur < dur + 1:
        r = mean_rr + rng.normal(0, s) + 0.02 * mean_rr * np.sin(2 * np.pi * 0.1 * tcur)
        if pause:  r *= 1.35; pause = False; ty = "N"
        elif rng.random() < pvc_prob: r *= 0.68; pause = True; ty = "V"
        else: ty = "N"
        tcur += max(r, 0.25); times.append(tcur); types.append(ty)
    tt = np.arange(0, dur, 1 / FS)
    sig = np.zeros_like(tt)
    prev = 0.3
    for tm, ty in zip(times, types):
        rrl = max(tm - prev, 0.25); prev = tm
        w = (tt > tm - 0.5) & (tt < tm + 0.6)
        sig[w] += beat(tt[w] - tm, rrl, ty == "V")
    sig += 0.05 * np.sin(2 * np.pi * 0.3 * tt + rng.uniform(0, 6)) + rng.normal(0, 0.015, tt.size)
    keep = [(x, ty) for x, ty in zip(times, types) if x < dur]
    return tt, sig, keep

ecg_rows, rp_rows = [], []
for c in CREW:
    for seg, hr, rm, pvc in [("rest", c["hr0"] + 3, c["rmssd0"], 0.0),
                             ("exercise", 128, 8, 0.0),
                             ("event_tachy_pvc", 112, 20, 0.10)]:
        tt, sig, beats = synth_ecg(hr, rm, 30, pvc)
        ecg_rows.append(pd.DataFrame(dict(data_origin="SYNTHETIC", crew_id=c["crew_id"], segment=seg,
                                          t_s=tt.round(4), ecg_mv=sig.round(4))))
        rp_rows += [dict(data_origin="SYNTHETIC", crew_id=c["crew_id"], segment=seg, r_time_s=round(x, 4), beat_type=ty)
                    for x, ty in beats]
pd.concat(ecg_rows).to_csv("ecg_250hz.csv", index=False)
pd.DataFrame(rp_rows).to_csv("ecg_rpeaks.csv", index=False)

# ---------------- sanity summary ----------------
print(vitals.groupby(["crew_id", "phase"])[["hr_bpm", "rmssd_ms", "sbp_mmhg", "dbp_mmhg", "spo2_pct"]].mean().round(1))
print(vitals.event_label.value_counts())
